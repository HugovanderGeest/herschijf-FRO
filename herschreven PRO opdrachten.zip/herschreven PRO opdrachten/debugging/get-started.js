
function onClick() {
  if (inputsAreEmpty()) {
    label.textContent = 'Error: Geen cijfer ingevoerd.';
    return;
  }
  updateLabel();
}
function inputsAreEmpty() {
  if (getNumber1() === '' || getNumber2() === '') {
    return true;
  } else {
    return false;
  }
}
function updateLabel() {
  const  addend1 = getNumber1();
  const  addend2 = getNumber2();
  const  sum = parseInt(addend1) + parseInt(addend2);
  label.textContent = parseInt(addend1) + ' + ' + parseInt(addend2) + ' = ' + sum;
}
function getNumber1() {
  return inputs[0].value;
}
function getNumber2() {
  return inputs[1].value;
}
let inputs = document.querySelectorAll('input');
let label = document.querySelector('p');
let button = document.querySelector('button');
button.addEventListener('click', onClick);
