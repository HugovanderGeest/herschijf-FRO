let f1 = document.getElementById("f1");
let f2 = document.getElementById("f2");
let f3 = document.getElementById("f3");
let punt = document.getElementById("punt");
let punten = 0;


const  fruit = ["&#127817; ", "&#127824; ", "&#127822; " , "&#127827; " , "&#55; " , "&#127820; " , "&#127818; "];

random_fruit();

function random_fruit() {
	let random1 = fruit [Math.floor(Math.random() * fruit.length)];
	f1.innerHTML = random1; 

	let random2 = fruit [Math.floor(Math.random() * fruit.length)];
	f2.innerHTML = random2; 

	let random3 = fruit [Math.floor(Math.random() * fruit.length)];
	f3.innerHTML = random3; 



	if (random1 == random2 && random1 == random3) {
	punten++;
		 punt.innerHTML = punten;
	}
}

