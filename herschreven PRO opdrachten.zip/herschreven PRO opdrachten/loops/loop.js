let dinner = [    
	"Spaghetti met ham en kaas", 
    "Macaroni met ham en kaas", 
    "Tagliatelli met ham en kaas", 
    "Spaghetti met spinaenszie en room", 
    "Macaroni met spinazie en room", 
    "Tagliatelli met spinazie en room", 
    "Spaghetti met gehakt-tomatensaus en kaas *", 
    "Macaroni met gehakt-tomatensaus en kaas *", 
    "Tagliatelli met gehakt-tomatensaus en kaas *", 
    "Spaghetti met spekjes, spinazie en room", 
    "Macaroni met spekjes, spinazie en room", 
    "Tagliatelli met spekjes, spinazie en room", 
    "Spaghetti met courgette en tomatensaus", 
    "Macaroni met courgette en tomatensaus", 
    "Tagliatelli met courgette en tomatensaus", 
    "Lasagne met courgette en tomatensaus", 
    "Lasagne met room, doperwten en tomataus", 
    "Lasagne met spinazie en tomatensaus en kaas"];

let menukaart = [];

for (let count = 0; count < dinner.length; count++) {
	console.log(dinner[count]);

}

for (item in dinner) {
	console.log(dinner[item]);

}

for (item of dinner) {
	console.log(item);
}

// dinner.forEach(function (item)) {
// 	console.log(item);
// }

let count = 0;
do {
	console.log(dinner[count]);
	count++;
	
} while (count < dinner.length);

count = 2; 
while (count < dinner.length) {
	console.log(dinner[count]);
	count++;
}