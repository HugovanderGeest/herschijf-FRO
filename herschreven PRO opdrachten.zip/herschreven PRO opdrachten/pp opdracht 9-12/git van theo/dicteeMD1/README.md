# Een oefening CSS Grid

### uitvoeren in pair programming

Probeer samen zoveel mogelijk van deze oefeing gedaan te hebben.

Na elk afgerond onderdeel dit even bij de docent melden voor akkoord.

* Na afloop van de training zorg je ervoor dat beide namen in een daarvoor bestemde metatag staan, het resultaat online staat, en op GitHub.

* In de README.md staat dan weer een linkje naar de live versie.

* De link naar GithUb komt in Magister onder vermelding van jullie beider namen.

Veel plezier.
