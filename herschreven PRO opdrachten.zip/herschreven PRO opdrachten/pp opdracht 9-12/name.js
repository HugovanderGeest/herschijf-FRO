const naam = document.getElementById("naam");

let deNamen = ["Teun van der Ploeg", "Hugo van der Geest"];

naam.innerHTML = deNamen[0] +", "+ deNamen[1];

 